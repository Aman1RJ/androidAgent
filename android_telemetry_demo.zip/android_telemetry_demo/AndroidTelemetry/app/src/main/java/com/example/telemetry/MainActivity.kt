package com.example.telemetry

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var client: TelemetryClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // These would be injected at build time via -PserverUrl or kept as config
        val serverUrl = BuildConfig.C2_SERVER_URL // set via gradle
        val authToken = "demo-lab-token" // builder could also bake token or set via UI
        client = TelemetryClient(this, serverUrl, authToken)
    }

    override fun onStart() {
        super.onStart()
        client.connect()
    }

    override fun onStop() {
        client.disconnect()
        super.onStop()
    }
}
