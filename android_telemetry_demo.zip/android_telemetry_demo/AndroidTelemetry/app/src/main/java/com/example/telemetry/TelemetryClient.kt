package com.example.telemetry

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class TelemetryClient(private val context: Context, private val serverUrl: String, private val authToken: String) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null

    fun connect() {
        val req = Request.Builder().url(serverUrl).addHeader("Authorization", "Bearer $authToken").build()
        ws = client.newWebSocket(req, socketListener)
    }

    fun disconnect() {
        ws?.close(1000, "client disconnect")
    }

    private val socketListener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            // send device_info on connect
            val info = deviceInfoJson()
            webSocket.send(info.toString())
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            handleCommand(text, webSocket)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            handleCommand(bytes.utf8(), webSocket)
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(code, reason)
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            // log; attempt reconnect logic could be added for lab
        }
    }

    private fun handleCommand(payload: String, ws: WebSocket) {
        // Expect JSON: { "command": "ping" }
        try {
            val obj = JSONObject(payload)
            when (obj.getString("command")) {
                "ping" -> {
                    val resp = JSONObject()
                    resp.put("response", "pong")
                    resp.put("ts", System.currentTimeMillis())
                    ws.send(resp.toString())
                }
                "device_info" -> {
                    val info = deviceInfoJson()
                    ws.send(info.toString())
                }
                else -> {
                    // ignore unknown command (no exec)
                }
            }
        } catch (e: Exception) {
            // ignore malformed commands
        }
    }

    private fun deviceInfoJson(): JSONObject {
        val info = JSONObject()
        info.put("type", "device_info")
        info.put("model", Build.MODEL ?: "unknown")
        info.put("manufacturer", Build.MANUFACTURER ?: "unknown")
        info.put("sdk_int", Build.VERSION.SDK_INT)
        info.put("android_release", Build.VERSION.RELEASE ?: "unknown")

        // Battery snapshot (benign)
        try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            info.put("battery_percent", if (bat >= 0) bat else JSONObject.NULL)
        } catch (_: Exception) {
            info.put("battery_percent", JSONObject.NULL)
        }
        info.put("timestamp", System.currentTimeMillis())
        return info
    }
}
