#!/usr/bin/env bash
set -euo pipefail

# Usage: ./build.sh <gradle_variant> <server_url>
GRADLE_VARIANT="${1:-assembleRelease}"
SERVER_URL="${2:-wss://c2.example.test:443/ws}"

echo "[builder] variant=$GRADLE_VARIANT server=$SERVER_URL"

# ensure executable gradlew
chmod +x ./gradlew

# Pass server URL as Gradle property so the APK is built with that endpoint baked in
./gradlew "$GRADLE_VARIANT" -PserverUrl="$SERVER_URL"

APK_PATH=$(find app/build/outputs/apk -type f -name "*.apk" | tail -n 1)
echo "[builder] built apk: $APK_PATH"

# Print path for Mythic parsing
echo "BUILT_APK=$APK_PATH"
